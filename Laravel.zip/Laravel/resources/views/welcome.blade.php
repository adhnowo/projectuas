@extends('layout.home')

@section('judul')
Home
@endsection