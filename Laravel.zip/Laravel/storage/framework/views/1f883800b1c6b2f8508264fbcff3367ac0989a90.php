<?php $__env->startSection('judul'); ?>
Home
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/home.blade.php ENDPATH**/ ?>